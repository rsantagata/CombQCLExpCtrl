﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedCode
{
    public class ExternalParameters : Parameters
    {
        public string Comments { get; set; }
        public double ExternalFactor { get; set; }
    }
}
