﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedCode
{
    public class DDSParameters : Parameters
    {
        public string DDSAddress { get; set; }
    }
}
